class PeeweeMetadata:
    ModelMeta = '__peewee__model__'
